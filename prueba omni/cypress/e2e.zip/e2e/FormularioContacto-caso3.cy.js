const { defineConfig } = require('cypress');

// //module.exports = defineConfig({
//   e2e: {
//     setupNodeEvents(on, config) {
//       // Implementa los escuchadores de eventos aquí si es necesario
//     },
//   },
// });
describe('Página de Contáctanos', () => {
    beforeEach(() => {
      // Configura el viewport para las pruebas
      cy.visit('https://www.zappos.com/'); // URL actualizada
    });
  
    it('Debería enviar el formulario de contacto correctamente en PC', () => {
      cy.viewport('macbook-15'); // Para pruebas en PC
      cy.get('#recipient-name').type('Juan Pérez'); // Selector ajustado
      cy.get('#recipient-email').type('juan.perez@example.com'); // Selector ajustado
      cy.get('#message-text').type('Este es un mensaje de prueba.'); // Selector ajustado
      cy.get('button[onclick="send()"]').click(); // Selector ajustado para el botón de enviar
      cy.on('window:alert', (text) => {
        expect(text).to.contains('Thanks for the message!!'); // Mensaje ajustado
      });
    });
  
    it('Debería enviar el formulario de contacto correctamente en móvil', () => {
      cy.viewport('iphone-6'); // Para pruebas en móvil
      cy.get('#recipient-name').type('Juan Pérez'); // Selector ajustado
      cy.get('#recipient-email').type('juan.perez@example.com'); // Selector ajustado
      cy.get('#message-text').type('Este es un mensaje de prueba.'); // Selector ajustado
      cy.get('button[onclick="send()"]').click(); // Selector ajustado para el botón de enviar
      cy.on('window:alert', (text) => {
        expect(text).to.contains('Thanks for the message!!'); // Mensaje ajustado
      });
    });
  });
  